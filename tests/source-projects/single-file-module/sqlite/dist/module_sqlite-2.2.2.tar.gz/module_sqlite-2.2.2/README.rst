A single-file module project.
